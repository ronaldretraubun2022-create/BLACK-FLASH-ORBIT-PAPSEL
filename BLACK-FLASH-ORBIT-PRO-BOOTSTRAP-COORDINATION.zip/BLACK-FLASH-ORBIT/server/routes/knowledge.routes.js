module.exports = require("./knowledgeRoutes");
